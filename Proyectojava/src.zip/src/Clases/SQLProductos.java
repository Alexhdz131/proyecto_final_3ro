package Clases;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SQLProductos extends Conexion {

    public boolean registrar(productos pro) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "INSERT INTO producto ( NOMBREP, PRECIOCOSTO, PRECIOVENTA) VALUE (?,?,?)";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getNOMBREP());
            ps.setDouble(2, pro.getPRECIOCOSTO());
            ps.setDouble(3, pro.getPRECIOVENTA());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }

        }
    }

    public boolean modificar(productos pro) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "UPDATE producto SET NOMBREP=?, PRECIOCOSTO=?, PRECIOVENTA=? WHERE PRODUCTOID=";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getNOMBREP());
            ps.setDouble(2, pro.getPRECIOCOSTO());
            ps.setDouble(3, pro.getPRECIOVENTA());
            ps.setInt(4, pro.getPRODUCTOID());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }

        }
    }

    public boolean eliminar(productos pro) {
        PreparedStatement ps = null;
        ResultSet rs =null;
        Connection con = getConexion();

        String sql = "DELETE producto WHERE NOMBREP=?";

        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getNOMBREP());
            rs = ps.executeQuery();
            
            if(rs.next()){
                pro.setPRODUCTOID(Integer.parseInt(rs.getString("PRODUCTOID")));
                pro.setNOMBREP(rs.getString("NOMBREP"));
                pro.setPRECIOCOSTO(Double.parseDouble(rs.getString("PRECIOCOSTO")));
                pro.setPRECIOVENTA(Double.parseDouble(rs.getString("PRECIOVENTA")));
                 return true;
            }
            return false;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }

        }
    }
     public boolean buscar(productos pro) {
        PreparedStatement ps = null;
        Connection con = getConexion();

        String sql = "SELECT * producto WHERE PRODUCTOID=";

        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, pro.getPRODUCTOID());
            ps.execute();
            return true;
        } catch (SQLException e) {
            System.err.println(e);
            return false;
        } finally {
            try {
                con.close();
            } catch (SQLException e) {
                System.err.println(e);
            }

        }
    }
}
