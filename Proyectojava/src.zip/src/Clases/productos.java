
package Clases;


public class productos {
    private int PRODUCTOID;
    private String NOMBREP;
    private Double PRECIOVENTA;
    private Double PRECIOCOSTO;

    public int getPRODUCTOID() {
        return PRODUCTOID;
    }

    public void setPRODUCTOID(int PRODUCTOID) {
        this.PRODUCTOID = PRODUCTOID;
    }

    public String getNOMBREP() {
        return NOMBREP;
    }

    public void setNOMBREP(String NOMBREP) {
        this.NOMBREP = NOMBREP;
    }

    public Double getPRECIOVENTA() {
        return PRECIOVENTA;
    }

    public void setPRECIOVENTA(Double PRECIOVENTA) {
        this.PRECIOVENTA = PRECIOVENTA;
    }

    public Double getPRECIOCOSTO() {
        return PRECIOCOSTO;
    }

    public void setPRECIOCOSTO(Double PRECIOCOSTO) {
        this.PRECIOCOSTO = PRECIOCOSTO;
    }

    public void setVisible(boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}
