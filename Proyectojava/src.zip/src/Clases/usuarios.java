
package Clases;


public class usuarios {
    private int USUARIOSID;
    private String USUARIO;
    private String PASSWORD;
    private String NOMBREU;
    private String CORREO;
    private String LAST_SESSION;
    private int ID_TIPO;
    private String NOMBRET;

    public int getUSUARIOSID() {
        return USUARIOSID;
    }

    public void setUSUARIOSID(int USUARIOSID) {
        this.USUARIOSID = USUARIOSID;
    }

    public String getUSUARIO() {
        return USUARIO;
    }

    public void setUSUARIO(String USUARIO) {
        this.USUARIO = USUARIO;
    }

    public String getPASSWORD() {
        return PASSWORD;
    }

    public void setPASSWORD(String PASSWORD) {
        this.PASSWORD = PASSWORD;
    }

    public String getNOMBREU() {
        return NOMBREU;
    }

    public void setNOMBREU(String NOMBREU) {
        this.NOMBREU = NOMBREU;
    }

    public String getCORREO() {
        return CORREO;
    }

    public void setCORREO(String CORREO) {
        this.CORREO = CORREO;
    }

    public String getLAST_SESSION() {
        return LAST_SESSION;
    }

    public void setLAST_SESSION(String LAST_SESSION) {
        this.LAST_SESSION = LAST_SESSION;
    }

    public int getID_TIPO() {
        return ID_TIPO;
    }

    public void setID_TIPO(int ID_TIPO) {
        this.ID_TIPO = ID_TIPO;
    }

    public String getNOMBRET() {
        return NOMBRET;
    }

    public void setNOMBRET(String NOMBRET) {
        this.NOMBRET = NOMBRET;
    }

   
    

    
    
    
}
